module ElevatorSim {
	requires junit;
	requires java.desktop;
}