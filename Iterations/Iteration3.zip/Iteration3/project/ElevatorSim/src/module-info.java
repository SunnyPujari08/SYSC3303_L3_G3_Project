module ElevatorSim {
	requires junit;
}